// initial id for new customer
let nextId = 0;

// reducer mail logic for all actions
const reducers = (state = [], action) => {
  console.log(action);
  switch (action.type) {
    case "ADDCUSTOMER":
      return [
        ...state,
        {
          ...action.payload,
          id: nextId++
        }
      ];
    case "REMOVECUSTOMER":
      const newState = [...state];
      const findIndex = state.findIndex(
        (customer) => customer.id === action.payload
      );
      if (findIndex >= 0) {
        newState.splice(findIndex, 1);
      }
      return newState;
    case "EDITCUSTOMER":
      const newEditState = [...state];
      const findEditIndex = state.findIndex(
        (customer) => customer.id === action.payload.id
      );
      if (findEditIndex >= 0) {
        newEditState[findEditIndex] = action.payload.details;
      }
      return newEditState;
    default:
      return state;
  }
};

export default reducers;
