// Add customer action
const addCustomer = () => {
  return "ADDCUSTOMER";
};

// remove customer action
const removeCustomer = () => {
  return "REMOVECUSTOMER";
};

// edit customer action
const editCustomer = () => {
  return "EDITCUSTOMER";
};

export { addCustomer, removeCustomer, editCustomer };
