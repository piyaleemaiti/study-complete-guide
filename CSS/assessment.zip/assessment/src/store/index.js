import { createStore } from "redux";
import reducers from "../reducers";

// store created
const store = createStore(reducers);

export default store;
