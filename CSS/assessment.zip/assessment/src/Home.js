import { useState, useEffect } from "react";
import { connect } from "react-redux";

import { addCustomer, editCustomer, removeCustomer } from "./actions";
import "./styles.css";

const Home = (props) => {
  const [customerList, setCustomers] = useState(props.state);

  useEffect(() => {
    const newCustomer = {
      name: "Piyalee",
      address: "Bangalore"
    };
    props.addCustomer(newCustomer);
  }, [props]);

  // Edit customer details - onclick edit form open
  const editCustomer = (index) => {
    const newCustomerList = [...customerList];
    const customer = newCustomerList[index];
    customer.edit = true;
    setCustomers(newCustomerList);
  };

  // on input field change date saved to state
  const handleInputChange = (e, index) => {
    const {
      target: { name, value }
    } = e;
    const newCustomerList = [...customerList];
    if (name === "customerName") {
      newCustomerList[index].name = value;
      if (value === "") {
        newCustomerList[index].error = true;
      } else {
        newCustomerList[index].error = false;
      }
    }
    setCustomers(newCustomerList);
  };

  // save edited customer details
  const saveCustomer = (index) => {
    const newCustomerList = [...customerList];
    const customer = newCustomerList[index];
    if (!customer.error) {
      customer.edit = false;
      setCustomers(newCustomerList);
      props.editCustomer({ id: customer.id, details: customer });
    }
  };

  // cancel edit data
  const cancelSave = (index) => {
    const newCustomerList = [...customerList];
    newCustomerList[index].edit = false;
    setCustomers(newCustomerList);
  };

  // delete customer details
  const deleteCustomer = (index) => {
    if (window.confirm("Are you sure want to delete the customer?")) {
      const newCustomerList = [...customerList];
      const customer = newCustomerList[index];
      props.removeCustomer(customer.id);
      newCustomerList.splice(index, 1);
      setCustomers(newCustomerList);
    }
  };

  return (
    <div className="App">
      <h1>Customers:</h1>
      {/* customer List rendering */}
      {customerList.length > 0 ? (
        customerList.map((customer, i) => (
          <div className="customerContainer" key={`${customer.id}-${i}`}>
            <div className="detailsSection">
              {customer.edit ? (
                <input
                  type="text"
                  name="customerName"
                  value={customer.name}
                  onChange={(e) => handleInputChange(e, i)}
                />
              ) : (
                <p className="custName">{customer.name}</p>
              )}
              <p>Address: {customer.address}</p>
            </div>
            <div className="actionArea">
              {customer.edit ? (
                <div>
                  {customer.error && (
                    <p className="error">
                      Please don't save as blank. Fill with some value
                    </p>
                  )}
                  <button
                    disabled={customer.error}
                    className={`${customer.error ? "disable" : "button"}`}
                    onClick={() => saveCustomer(i)}
                  >
                    Save
                  </button>
                  <button className="cancel" onClick={() => cancelSave(i)}>
                    Cancel
                  </button>
                </div>
              ) : (
                <div>
                  <button className="button" onClick={() => editCustomer(i)}>
                    Edit
                  </button>
                  <button className="delete" onClick={() => deleteCustomer(i)}>
                    Delete
                  </button>
                </div>
              )}
            </div>
          </div>
        ))
      ) : (
        <p>No Customer Data Exist. Please add using form.</p>
      )}
    </div>
  );
};

const mapDispatchToProps = (dispatch) => {
  return {
    addCustomer: (payload) => dispatch({ type: addCustomer(), payload }),
    editCustomer: (payload) => dispatch({ type: editCustomer(), payload }),
    removeCustomer: (payload) => dispatch({ type: removeCustomer(), payload })
  };
};

const mapStateToProps = (state) => {
  return {
    state
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);
