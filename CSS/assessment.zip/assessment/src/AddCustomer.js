import React, { useState } from "react";
import { set } from "immutable";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";

import { addCustomer } from "./actions";
import "./styles.css";

// Add Cutomer Form
const AddCustomer = (props) => {
  const [formData, setFormData] = useState({
    name: "",
    address: ""
  });

  // input changes handled
  const handleInputChange = ({ target }) => {
    const { name, value } = target;
    setFormData((state) => set(state, [name], value));
  };

  // Add buttom disable and enable config
  const isEnableSave = () => {
    if (formData.name !== "" && formData.address !== "") {
      return false;
    } else {
      return true;
    }
  };

  // Add customer details
  const saveCustomer = () => {
    props.addCustomer(formData);
    console.log("saveCustomer", props);
    setFormData({
      name: "",
      address: ""
    });
    return <Redirect to="/" />;
  };

  // Add form
  return (
    <div className="addCustomerForm">
      <h1>Add Customer:</h1>
      <div className="fieldArea">
        Name:
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleInputChange}
        />
      </div>
      <div className="fieldArea">
        Address:
        <input
          type="text"
          name="address"
          value={formData.address}
          onChange={handleInputChange}
        />
      </div>
      <div className="fieldArea">
        <button
          onClick={saveCustomer}
          disabled={isEnableSave()}
          className={`${isEnableSave() ? "disable" : "button"}`}
        >
          Add
        </button>
      </div>
    </div>
  );
};

// dispatch functions for redux
const mapDispatchToProps = (dispatch) => {
  return {
    addCustomer: (payload) => dispatch({ type: addCustomer(), payload })
  };
};

// redux store value
const mapStateToProps = (state) => {
  return {
    state
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(AddCustomer);
