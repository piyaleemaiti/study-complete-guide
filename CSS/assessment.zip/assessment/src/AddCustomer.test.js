import React from "react";
import renderer from "react-test-renderer";
import AddCustomer from "./AddCustomer";

const props = {
  name: "",
  address: ""
};

it("Add Customer Page", () => {
  const tree = renderer.create(<AddCustomer {...props} />).toJSON();
  expect(tree).toMatchSnapshot();
});
